import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import f1_score, confusion_matrix, classification_report

SEED = 42

def run_nlp_pipeline():
    train = pd.read_csv("datasets/nlp/nlp/nlp_train.csv")
    val = pd.read_csv("datasets/nlp/nlp/nlp_val.csv")

    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1,2), max_features=2000)),
        ("clf", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=SEED))
    ])

    grid = GridSearchCV(pipeline, {"clf__C":[0.1, 1, 10]}, cv=3, scoring="f1_macro")
    print("\nTraining NLP model...")
    grid.fit(train["text"], train["label"])

    model = grid.best_estimator_
    preds = model.predict(val["text"])
    
    print(f"NLP F1 Macro: {round(f1_score(val['label'], preds, average='macro'),4)}")
    print("\nClassification Report:\n", classification_report(val["label"], preds))

    # --- FIX: Added Confusion Matrix Visualization (Resolves plt/sns warnings) ---
    cm = confusion_matrix(val["label"], preds)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=model.classes_, yticklabels=model.classes_)
    plt.title("NLP Confusion Matrix (Requirement 3.4)")
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.show()

    # Error Analysis
    errors = val[preds != val["label"]]
    print("\nSample misclassified:\n", errors["text"].head(3))

    # Robustness & Fairness
    print("\n--- 5. Robustness & Fairness ---")
    test_noise = ["The product is great", "The product is graet"] # Spelling noise
    print(f"Typo Robustness Test: {model.predict(test_noise)}")
    
    print("\nFairness Reflection: "
          "The model may rely on specific emotive words (e.g., 'hate', 'amazing'). "
          "Potential bias exists if the training data associates specific product names "
          "with negative labels, leading to unfair punishment of those brands.")

if __name__=="__main__":
    run_nlp_pipeline()

#Lenon, Danielle Laurence B. | CS-301 | 2.18.2026