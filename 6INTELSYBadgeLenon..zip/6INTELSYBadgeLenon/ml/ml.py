import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder, PolynomialFeatures
from sklearn.metrics import f1_score, confusion_matrix, classification_report
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.inspection import permutation_importance

SEED = 42
np.random.seed(SEED)

def run_ml_pipeline():
    # 1. EDA & Data Quality
    df = pd.read_csv("datasets/ml/ml/ml_train.csv")
    target_col = "cat_region"
    X = df.drop(columns=[target_col])
    y = df[target_col]

    print("\n--- 1. EDA & Data Quality ---")
    print(f"Missing Values: {df.isnull().sum().sum()}")
    print(f"Class Balance:\n{y.value_counts(normalize=True)}")
    
    num_cols = X.select_dtypes(include=["int64","float64"]).columns
    cat_cols = X.select_dtypes(include=["object","category","string"]).columns
    
    plt.figure(figsize=(10, 6))
    sns.heatmap(df[num_cols].corr(), annot=True, cmap='coolwarm', fmt=".2f")
    plt.title("Correlation Heatmap (Requirement 1.1)")
    plt.show()

    # 2. Preprocessing & Feature Engineering
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)

    preproc = ColumnTransformer([
        ("num", Pipeline([
            ("imp", SimpleImputer(strategy="mean")),
            ("poly", PolynomialFeatures(degree=2, include_bias=False)),
            ("sc", StandardScaler())
        ]), num_cols),
        ("cat", Pipeline([
            ("imp", SimpleImputer(strategy="most_frequent")),
            ("oh", OneHotEncoder(handle_unknown="ignore"))
        ]), cat_cols)
    ])

    # 3. Modeling & Validation
    baseline = DummyClassifier(strategy="most_frequent").fit(X_train, y_train)
    base_f1 = f1_score(y_val, baseline.predict(X_val), average="macro")

    gb_model = Pipeline([
        ("prep", preproc),
        ("clf", HistGradientBoostingClassifier(max_iter=300, learning_rate=0.05, random_state=SEED))
    ])
    
    print("\n--- 3. Training Gradient Boosting ---")
    gb_model.fit(X_train, y_train)
    preds = gb_model.predict(X_val)
    f1 = f1_score(y_val, preds, average="macro")

    # 4. Evaluation
    print(f"\nFINAL ML F1 Macro: {round(f1,4)} (Improvement: {round(f1-base_f1,4)})")
    print("\nClassification Report:\n", classification_report(y_val, preds))

    # 5. Explainability 
    print("\n--- 5. Explainability ---")
    result = permutation_importance(gb_model, X_val, y_val, n_repeats=10, random_state=SEED)
    importance_df = pd.DataFrame({
        'feature': X.columns,
        'importance': result.importances_mean
    }).sort_values(by='importance', ascending=False)

    plt.figure(figsize=(10,6))
    sns.barplot(data=importance_df, x='importance', y='feature', hue='feature', palette='viridis', legend=False)
    plt.title("Global Feature Importance (Permutation)")
    plt.show()

    mis_idx = np.where(preds != y_val)[0]
    if len(mis_idx) > 0:
        idx = mis_idx[0]
        print(f"Local Rationale: Instance at index {idx} was misclassified.")
        print(f"True Label: {y_val.iloc[idx]} | Predicted: {preds[idx]}")
        print("Potential Cause: Overlapping feature values between regions.")

if __name__ == "__main__":
    run_ml_pipeline()

#Lenon, Danielle Laurence B. | CS-301 | 2.18.2026