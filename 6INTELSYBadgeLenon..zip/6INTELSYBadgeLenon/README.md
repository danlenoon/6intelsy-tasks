
# Intelligent Systems — Hands‑On Badging Exam Pack

**Tracks:** Machine Learning • Introduction to Deep Learning • Natural Language Processing  
**Proctored Duration:** 3 hours

## Structure
```
6INTELSYBadgeLenon/
├── datasets/
    ├── images/
        ├── train/{circle,square,triangle}/*.png
        └── val/{circle,square,triangle}/*.png
    ├── ml/
        └── {ml_train.csv, ml_val.csv, ml_test.csv}
    └── nlp/
        └── nlp/{nlp_train.csv, nlp_val.csv, nlp_test.csv}
├── dl/
    └── deep_learning.py
├── ml/
    └── machine_learning.py
├── nlp/
    └── nlp.py
├── 6Intelsy Midterm Badging Exam.pdf
├── README.md
├── report.docx
├── report.pdf
├── requirements_torch.txt
└── requirements.txt
```

## Quickstart

1. Create a Python 3.10+ virtual environment.
2. Install dependencies:
   - For Machine Learning and/or Natural Language Processing: `pip install -r requirements.txt`
   - For Deep Learning with PyTorch: `pip install -r requirements_torch.txt`
3. Run scripts in order:  
   ```bash
   python machine_learning.py
   python nlp.py
   python deep_learning.py
4. Follow the PDF for acceptance criteria and rubric.