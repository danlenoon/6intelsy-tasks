import re  #re for text manipulation using regular expressions
import tkinter as tk  #tkinter for GUI components
from tkinter import scrolledtext  #scrolledtext for scrollable text widget
import sympy as sp  #sympy for symbolic math
from sympy.parsing.sympy_parser import (
    parse_expr,  #parse_expr converts string into sympy expression
    standard_transformations,  #standard_transformations act as standard parsing rules
    implicit_multiplication_application  #implicit_multiplication_application allows parsing '2x' as '2*x'
)
from word2number import w2n  #word2number and w2n convert word numbers (like one) to integers

#llm_math_parser is a function to parse and clean natural language math input
def llm_math_parser(text):
    text = text.lower().strip()  #normalizes text to lowercase and remove leading/trailing spaces
    text = text.replace('^', '**')  #replaces caret '^' with Python exponent operator '**'

    #removes derivative phrases to avoid parsing errors
    text = re.sub(r'with (the )?respect to x', '', text)

    #removes calculus-related keywords that are not part of the expression
    commands = [
        'integrate', 'integral',
        'differentiate', 'derivative', 'derive',
        'rate of change', 'slope of',
        'velocity', 'acceleration',
        'area under', 'antiderivative'
    ]
    for cmd in commands:
        text = text.replace(cmd, '')  #strips out unwanted commands

    #handles grouping phrases for order of operations
    text = re.sub(r'the quantity of', '(', text)  #replaces 'the quantity of' with '('
    text = re.sub(r'all raised to the power of', ')**', text)  #replaces exponent phrases

    #supports alternative wording for exponents
    text = re.sub(r'raise(d)? to the power of', '**', text)  #converts 'raised to the power of' to '**'

    #removes commas to avoid parsing issues
    text = text.replace(',', '')

    #converts worded numbers to numeric values
    words = text.split()  #splits input into individual words
    rebuilt = []  #rebuilts expression as list
    buffer = []  #buffers to collect consecutive number words

    for w in words:
        try:
            w2n.word_to_num(w)  #checks if word is a number
            buffer.append(w)  #collects number words
        except:
            if buffer:
                rebuilt.append(str(w2n.word_to_num(" ".join(buffer))))  #converts buffered words to number
                buffer = []  #clears buffer
            rebuilt.append(w)  #appends non-number word

    if buffer:
        rebuilt.append(str(w2n.word_to_num(" ".join(buffer))))  #converts any remaining buffered number words

    text = " ".join(rebuilt)  #recombines into single string

    #replaces english math operators and functions with Python/sympy symbols
    replacements = {
        'plus': '+',  #replaces 'plus' with '+'
        'minus': '-',  #replaces 'minus' with '-'
        'times': '*',  #replaces 'times' with '*'
        'multiplied by': '*',  #replaces 'multiplied by' with '*'
        'divide by': '/',  #replaces 'divide by' with '/'
        'divided by': '/',  #replaces 'divided by' with '/'
        'over': '/',  #replaces 'over' with '/'
        'to the power of': '**',  #replaces 'to the power of' with '**'
        'squared': '**2',  #replaces 'squared' with '**2'
        'cubed': '**3',  #replaces 'cubed' with '**3'

        'sine': 'sin',  #replaces 'sine' with SymPy sin()
        'cosine': 'cos',  #replaces 'cosine' with SymPy cos()
        'tangent': 'tan',  #replaces 'tangent' with SymPy tan()
        'secant': 'sec',  #replaces 'secant' with SymPy sec()
        'cosecant': 'csc',  #replaces 'cosecant' with SymPy csc()
        'cotangent': 'cot',  #replaces 'cotangent' with SymPy cot()

        'pi': 'pi',  #keeps 'pi' as symbolic pi
        'e': 'E'  #replaces 'e' with SymPy constant E
    }

    for phrase, symbol in replacements.items():
        text = re.sub(r'\b' + phrase + r'\b', symbol, text)  #replaces all occurrences in text

    #removes filler words that are safe to ignore
    filler = [
        'what', 'is', 'the', 'answer', 'result',
        'provide', 'find', 'calculate', 'solve',
        'me', 'of'
    ]
    for f in filler:
        text = re.sub(r'\b' + f + r'\b', '', text)  #removes filler words

    text = re.sub(r'\s+', ' ', text).strip()  #normalizes spaces

    #wraps trigonometry functions in parentheses for sympy
    text = re.sub(
        r'\b(sin|cos|tan|sec|csc|cot)\s+([a-z0-9Epi/().]+)',
        r'\1(\2)', text  #ensures functions like sin x become sin(x)
    )

    return text  #return the cleaned and parsed expression

#solve_math_problem is a function to evaluate math problem from user input
def solve_math_problem(user_input):
    x = sp.Symbol('x')  #defines symbolic variable x
    transformations = standard_transformations + (implicit_multiplication_application,)  #parsing transformations
    raw = user_input.lower()  #lowercase input for keyword checks

    #greeting terms
    if any(w in raw for w in ['hello', 'hi', 'hey']):
        return "What's up, Dan?"  #responds with greeting

    #keywords to detect derivative or integral requests
    derivative_keywords = [
        'derivative', 'derive', 'differentiate',
        'rate of change', 'velocity', 'acceleration'
    ]
    integral_keywords = [
        'integral', 'integrate', 'area under', 'antiderivative'
    ]

    expr_str = llm_math_parser(user_input)  #parses user input into sympy expression

    try:
        expr = parse_expr(expr_str, transformations=transformations)  #converts string to SymPy expression

        #handles derivatives
        if any(k in raw for k in derivative_keywords):
            if 'acceleration' in raw:
                res = sp.diff(expr, x, 2)  #second derivative for acceleration
                return f"The acceleration of {expr} is {res}"
            res = sp.diff(expr, x)  #first derivative
            return f"The derivative of {expr} is {res}"

        #handles integrals
        if any(k in raw for k in integral_keywords):
            res = sp.integrate(expr, x)  #computes integral
            return f"The integral of {expr} is {res} + C"

        #numeric evaluation
        if expr.is_number:
            val = float(expr.evalf())  #evaluates numerically
            return f"The result of '{user_input}' is {int(val) if val.is_integer() else val}"

        #symbolic simplification
        return f"The result of '{user_input}' is {sp.simplify(expr)}"

    except Exception:
        return "The math syntax is unclear. Please try a cleaner expression."  #handles parse errors

#send_message is a function to send message from entry box to chat window via the GUI
def send_message(event=None):
    user_text = entry.get()  #gets user input
    if not user_text.strip():  #ignores empty input
        return

    chat_window.config(state=tk.NORMAL)  #enables editing
    chat_window.insert(tk.END, "\nYOU: " + user_text + "\n", "user_tag")  #displays user message
    entry.delete(0, tk.END)  #clears entry box

    response = solve_math_problem(user_text)  #gets chatbot response
    chat_window.insert(tk.END, "CHATBOT: " + response + "\n")  #displays chatbot response

    chat_window.config(state=tk.DISABLED)  #disables editing
    chat_window.see(tk.END)  #scrolls to latest message

#initialize GUI
app = tk.Tk()
app.title("Math Chatbot GUI")  #window title
app.geometry("520x520")  #window size
app.minsize(300, 300)  #minimum window size

#input frame with text entry and submit button
input_frame = tk.Frame(app)
input_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
input_frame.columnconfigure(0, weight=1)

entry = tk.Entry(input_frame, font=("Arial", 13))  #input box
entry.grid(row=0, column=0, sticky="ew", padx=(0, 10))
entry.bind("<Return>", send_message)  #bind Enter key to send_message

btn = tk.Button(
    input_frame,
    text="SUBMIT",
    command=send_message,  #calls send_message when clicked
    bg="#2F4452",  #button color
    fg="white",  #text color
    font=("Arial", 13, "bold"),  #font
    padx=25  #padding
)
btn.grid(row=0, column=1)  #place button

#chat display frame
chat_frame = tk.Frame(app)
chat_frame.pack(expand=True, fill=tk.BOTH, padx=10, pady=5)

chat_window = scrolledtext.ScrolledText(chat_frame, wrap=tk.WORD, font=("Arial", 13))  #scrollable chat window
chat_window.pack(expand=True, fill=tk.BOTH)
chat_window.tag_config("user_tag", foreground="#2F4452", font=("Arial", 13, "bold"))  #style for user messages

#initial chatbot greeting
chat_window.insert(
    tk.END,
    "CHATBOT: Greetings to you, Danielle Laurence Lenon! Please type your input on the prompt box below, "
    "as long as it is related to mathematics. Finally, click the SUBMIT button once ready.\n"
)
chat_window.config(state=tk.DISABLED)  #disable manual editing

app.mainloop()  #start GUI loop

'''
AI Tools Used: ChatGPT and Google Gemini

USE-CASE SCENARIOS

1. Basic operations
ChatGPT: 67 + 67
RESULT (from ChatGPT): The answer is 134.

Gemini: 67 + 67
RESULT (from Google Gemini): 134

RESULT (from my CHATBOT): The result of '67' is 134
The code correctly parses numeric input and directly evaluates expressions using SymPy.
llm_math_parser preserves numeric values; parse_expr and evalf handle the calculation accurately.

2. Worded operations
ChatGPT: six divided by seven multiplied by eight minus nine plus ten
RESULT (from ChatGPT): The answer is -0.142857… (or exactly -1/7).

Gemini: six divided by seven multiplied by eight minus nine plus ten
RESULT (from Google Gemini): 7.857142857142857

RESULT (from my CHATBOT): The result of 'six divided by seven multiplied by eight minus nine plus ten' is 7.857142857142857
The code converts worded numbers into digits using word2number.
Replacement of words like 'divided by' and 'multiplied by' allows SymPy to evaluate the expression correctly.
This demonstrates that llm_math_parser and parse_expr are sufficient for worded numeric expressions.

3. Basic calculus problem
ChatGPT: sin(x) + cos(y)
RESULT (from ChatGPT): The answer is sin(x) + cos(y).

Gemini: sin(x) + cos(y)
RESULT (from Google Gemini): $\sin(x) + \cos(y)$

RESULT (from my CHATBOT): The result of 'sin(x) + cos(y)' is sin(x) + cos(y)
The code recognizes standard math functions and correctly wraps trigonometric functions.
parse_expr interprets the symbols correctly, preserving symbolic expressions as expected.

4. Worded calculus problem
ChatGPT: what is the integral of x cubed plus ten x divided by two
RESULT (from ChatGPT): The integral of x^3+10x/x dx is x^4/8 + 5x^2/2 + C

Gemini: what is the integral of x cubed plus ten x divided by two
RESULT (from Google Gemini): x^4/8 + 5x^2/2 + C

RESULT (from my CHATBOT): The integral of x**3 + 5*x is x**4/4 + 5*x**2/2 + C
The code parses worded input and converts it into sympy expressions using llm_math_parser.
Integral is correctly computed symbolically using SymPy's integrate function.
Minor differences in interpretation (x cubed plus ten x divided by two) highlight parsing nuances, but overall, code is sufficient for solving symbolic integrals.
'''

#Lenon, Danielle Laurence B. | CS-301 | 2.6.2026