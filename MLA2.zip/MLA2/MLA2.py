import pyttsx3
import speech_recognition as sr
import os

script_directory = os.path.dirname(__file__)
TEXT_TO_SPEECH_FILE = os.path.join(script_directory, "text_to_speech.wav")

#Initialize TTS Engine once
try:
    engine = pyttsx3.init(driverName='sapi5')
except Exception as e:
    print(f"Error initializing TTS engine: {e}")
    exit()

#MAIN MENU
while True:
    print("\n==============================")
    print("   Midterm Lab Activity 2   ")
    print("==============================")
    print("1\tTEXT-TO-SPEECH")
    print("2\tSPEECH-TO-TEXT")
    print("3\tEXIT")
    print("==============================")
    choice = input("Enter your choice: ").strip()

    #1  TEXT-TO-SPEECH
    if choice == "1":
        print("\nTEXT-TO-SPEECH")
        text = input("Enter the text you want to convert to speech: ")

        try:
            engine.save_to_file(text, TEXT_TO_SPEECH_FILE)
            engine.runAndWait()
            print(f"\nAudio saved as:\n{TEXT_TO_SPEECH_FILE}")
        except Exception as e:
            print(f"ERROR generating audio file: {e}")

    #2  SPEECH-TO-TEXT
    elif choice == "2":
        print("\nSPEECH-TO-TEXT (From Audio File)")
        audio_extensions = ('.wav', '.mp3', '.flac', '.ogg', '.aiff', '.aif')
        audio_files = [f for f in os.listdir(script_directory) if f.lower().endswith(audio_extensions)]

        if not audio_files:
            print("No audio files found in the folder:")
            print(script_directory)
            print("Please add an audio file and try again.")
            continue

        def index_to_letters(index):
            letters = ""
            
            while True:
                letters = chr(ord('A') + (index % 26)) + letters
                index = index // 26 - 1
                if index < 0:
                    break
            return letters

        letter_map = {}
        print("\nAvailable audio file/s:")
        
        for i, file_name in enumerate(audio_files):
            label = index_to_letters(i)
            letter_map[label.upper()] = file_name
            print(f"{label}\t{file_name}")

        user_choice = input("\nEnter the letter of the audio file you want to use: ").strip().upper()

        if user_choice not in letter_map:
            print("ERROR: Invalid selection. Please enter a valid letter corresponding to the file.")
            continue

        audio_file_path = os.path.join(script_directory, letter_map[user_choice])
        print(f"\nSelected audio file: {letter_map[user_choice]}")
        print("Processing speech...")

        r = sr.Recognizer()

        try:
            if not audio_file_path.lower().endswith('.wav'):
                from pydub import AudioSegment, effects
                temp_wav = os.path.join(script_directory, "temp_audio.wav")
                AudioSegment.from_file(audio_file_path).export(temp_wav, format="wav")
                audio_file_path = temp_wav

            from pydub import AudioSegment, effects
            sound = AudioSegment.from_wav(audio_file_path)
            sound = effects.normalize(sound)
            sound = effects.strip_silence(sound, silence_len=100, silence_thresh=-50)
            sound.export(audio_file_path, format="wav")

            with sr.AudioFile(audio_file_path) as source:
                audio = r.record(source)

            result = r.recognize_google(audio)
            print("\nSPEECH-TO-TEXT Output:")
            print(result)

        except ImportError:
            print("ERROR: pydub is required for non-WAV files. Install it with 'pip install pydub'.")
        except sr.UnknownValueError:
            print("Sorry, the audio could not be understood.")
        except sr.RequestError as e:
            print(f"Could not request results from Google service; {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")
        finally:
            if 'temp_wav' in locals() and os.path.exists(temp_wav):
                os.remove(temp_wav)

    #3  EXIT
    elif choice == "3":
        print("\nThank you for using my services! Bye!")
        break

    else:
        print("\nINVALID INPUT! Please enter 1, 2, or 3.")

#Lenon, Danielle Laurence B. | CS-301 | 1.21.2026